import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.io.*;
import java.util.ArrayList;

import static java.awt.Color.black;

public class window {
    static JFrame f;
    private static ArrayList<course> loadAllCourses(File Folder){
        ArrayList<course> courses= new ArrayList<>();
        for (String name :Folder.list()){
            File file= new File(Folder.getPath()+File.separator+name);
            courses.add(course.read(file));
        }
        return courses;
    }
    public static void init(File loc){
        // courses
            ArrayList<course> courses = loadAllCourses(loc);
            ArrayList<JInternalFrame> iframes = new ArrayList<>();

        // internaljframe setum for all courses
        f = new JFrame("Planner");
        f.setLayout(new FlowLayout());
        for(course c:courses){
           iframes.add(new JInternalFrame(c.name,false,true,true,false));

        }
        //for all courses setup content in  internal j frame
        for(JInternalFrame i:iframes){
            // set init for course panel
            course thisCourse=(courses.get(iframes.indexOf(i)));
            thisCourse.sort();
            i.setSize(300,800);
            i.setMaximumSize(new Dimension(300,4000));
            i.setLayout(new FlowLayout());

            //init stats panel
            JPanel s= new JPanel();
            s.setLayout(new BoxLayout(s,BoxLayout.PAGE_AXIS));
            s.setPreferredSize(new Dimension(300,100));
            s.setMinimumSize(new Dimension(300,40));
            s.add(new JLabel("Due Date: "+thisCourse.DueDate));
            s.add(new JLabel(thisCourse.DonePercent()+"% finished"));
            s.add(new JLabel("Hrs of studying needed per day: "+thisCourse.neededHrsPerDayTilExam()));
            s.setBorder(BorderFactory.createBevelBorder(1));
            s.setVisible(true);


            // init tasks panel
            JPanel t = new JPanel();
            t.add(s);
            // pfusch

            t.setLayout(new BoxLayout(t, BoxLayout.Y_AXIS));
            t.setPreferredSize(new Dimension(300, 500));
            t.setBorder(BorderFactory.createBevelBorder(1));
            for(task ta:thisCourse.ToDoTaskList){
                JPanel temp= new JPanel();
                temp.setLayout(new FlowLayout());

                temp.setPreferredSize(new Dimension(300,30*ta.duration));
                temp.setBorder(BorderFactory.createBevelBorder(1));
                temp.setBackground(Color.GRAY);
                temp.add(new JLabel(ta.name));
                temp.add(new JLabel("Dauer: "+ta.duration));

                temp.add(new JCheckBox("Complete Task:"));
                temp.setVisible(true);
                t.add(temp);

            }
            t.setVisible(true);



            i.add(t);
            f.add(i);
            i.setVisible(true);
        }




        f.setSize(700, 900);

        f.show();
    }
}
